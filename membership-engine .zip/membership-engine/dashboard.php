<?php
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
}

$user_id = $_SESSION['user_id'];

$user = $conn->query("SELECT * FROM users WHERE id=$user_id")->fetch_assoc();

$sub = $conn->query("
SELECT p.name FROM subscriptions s
JOIN plans p ON s.plan_id=p.id
WHERE s.user_id=$user_id
")->fetch_assoc();

$plan = $sub['name'] ?? "Free";

// News limit
$limit = 5;
if ($plan == "Paid") $limit = 20;
if ($plan == "Gold") $limit = 100;
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(to right, #4facfe, #00f2fe);
    font-family: 'Segoe UI';
}

.card {
    border-radius: 15px;
}

.header-card {
    background: white;
}

.plan-badge {
    font-size: 14px;
    padding: 5px 10px;
    border-radius: 20px;
}

.free { background: gray; color: white; }
.paid { background: orange; color: white; }
.gold { background: gold; color: black; }

.news-card {
    transition: 0.3s;
}
.news-card:hover {
    transform: scale(1.05);
}
</style>

</head>

<body>

<div class="container mt-5">

<!-- HEADER -->
<div class="card header-card p-4 shadow-lg">
    <div class="d-flex justify-content-between align-items-center">
        <h3>👋 Welcome, User</h3>

        <div>
            <span class="plan-badge <?php echo strtolower($plan); ?>">
                <?php echo $plan; ?> Plan
            </span>
            <a href="logout.php" class="btn btn-danger btn-sm ms-3">Logout</a>
        </div>
    </div>

    <div class="row mt-3">
        <div class="col-md-6">
            <h5>💰 Balance: ₹<?php echo $user['balance']; ?></h5>
        </div>
    </div>
</div>

<!-- ACTION CARDS -->
<div class="row mt-4">

<!-- Add Money -->
<div class="col-md-6">
<div class="card p-3 shadow">
<h5>💳 Add Money</h5>
<form action="add_money.php" method="POST">
<input name="amount" class="form-control mb-2" placeholder="Enter amount" required>
<button class="btn btn-success w-100">Add Money</button>
</form>
</div>
</div>

<!-- Subscribe -->
<div class="col-md-6">
<div class="card p-3 shadow">
<h5>📦 Subscribe Plan</h5>
<form action="subscribe.php" method="POST">
<select name="plan_id" class="form-select mb-2">
<option value="1">Free</option>
<option value="2">Paid</option>
<option value="3">Gold</option>
</select>
<button class="btn btn-primary w-100">Subscribe</button>
</form>
</div>
</div>

</div>

<!-- NEWS -->
<div class="card mt-4 p-4 shadow-lg">
<h4>📰 Latest News</h4>

<div class="row mt-3">
<?php
$news = [
"🚀 India launches new satellite",
"📈 Stock market hits record high",
"🤖 AI changing industries",
"🏏 Cricket world cup highlights",
"🎓 New education policy",
"⚡ EV industry booming",
"🌍 Climate awareness rising",
"🏥 Healthcare innovations",
"🛰️ Space missions success",
"💻 Tech companies expanding"
];

for ($i = 0; $i < $limit && $i < count($news); $i++) {
    echo "
    <div class='col-md-4'>
        <div class='card news-card p-3 mb-3 shadow'>
            <h6>{$news[$i]}</h6>
        </div>
    </div>";
}
?>
</div>

</div>

</div>

</body>
</html>