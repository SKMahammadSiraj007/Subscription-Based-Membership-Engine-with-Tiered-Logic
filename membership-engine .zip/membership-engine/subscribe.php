<?php
include 'db.php';

$user_id = $_SESSION['user_id'];
$plan_id = $_POST['plan_id'];

// Check if already subscribed
$existing = $conn->query("SELECT * FROM subscriptions WHERE user_id=$user_id");

if ($existing->num_rows > 0) {
    echo "Already subscribed! Plan updated.";
    $conn->query("DELETE FROM subscriptions WHERE user_id=$user_id");
}

// Get plan price
$plan = $conn->query("SELECT * FROM plans WHERE id=$plan_id")->fetch_assoc();
$price = $plan['price'];

// Get balance
$user = $conn->query("SELECT balance FROM users WHERE id=$user_id")->fetch_assoc();

if ($user['balance'] >= $price) {

    $conn->query("UPDATE users SET balance = balance - $price WHERE id=$user_id");

    $conn->query("INSERT INTO subscriptions(user_id,plan_id) VALUES($user_id,$plan_id)");

    header("Location: dashboard.php");

} else {
    echo "Not enough balance!";
}
?>