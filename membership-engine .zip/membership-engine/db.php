<?php
session_start();
$conn = new mysqli("localhost", "root", "Murali@2006", "membership_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}?>