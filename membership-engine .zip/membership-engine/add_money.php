<?php
include 'db.php';

$amount = $_POST['amount'];
$user_id = $_SESSION['user_id'];

$conn->query("UPDATE users SET balance = balance + $amount WHERE id=$user_id");

header("Location: dashboard.php");
?>